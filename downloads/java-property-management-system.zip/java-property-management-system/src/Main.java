import Properties.*;
import users.*;
import Storage.*;
import Exceptions.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
public class Main extends JFrame {
    private ArrayList<Property> allProperties = new ArrayList<>();
    private ArrayList<Customer> customers = new ArrayList<>();
    private ArrayList<Agent> agents = new ArrayList<>();
    private Customer loggedInCustomer = null;
    private Agent defaultAgent = null;
    static final Color BG = new Color(13, 17, 23);
    static final Color SURFACE = new Color(22, 27, 34);
    static final Color CARD = new Color(30, 37, 46);
    static final Color ACCENT = new Color(88, 166, 255);
    static final Color GREEN = new Color(56, 189, 132);
    static final Color GOLD = new Color(255, 196, 61);
    static final Color RED = new Color(248, 81, 73);
    static final Color TEXT = new Color(230, 237, 243);
    static final Color MUTED = new Color(110, 118, 129);
    static final Color BORDER = new Color(48, 54, 61);
    private JPanel contentArea;
    private CardLayout cardLayout;
    private JPanel dashContent;
    private CardLayout dashCards;
    private JLabel welcomeLbl, budgetLbl;
    private JPanel browseGrid, wishGrid, purBox, profileBox, agentsBox;
    public Main(ArrayList<Property> properties, ArrayList<Customer> customers, ArrayList<Agent> agents) {
        this.allProperties = properties;
        this.customers = customers;
        this.agents = agents;
        this.defaultAgent = agents.get(0);
        initUI();
        showPanel("LOGIN");
    }
    private void initUI() {
        setTitle("RealEstate Pro");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                FileManager.saveAll(allProperties, customers, agents);
                System.out.println("Data saved. Goodbye!");
                dispose();
                System.exit(0);
            }
        });
        setSize(1200, 760);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        cardLayout = new CardLayout();
        contentArea = new JPanel(cardLayout);
        contentArea.setBackground(BG);
        contentArea.add(buildLoginPanel(), "LOGIN");
        contentArea.add(buildRegisterPanel(), "REGISTER");
        contentArea.add(buildDashboard(), "DASHBOARD");
        add(contentArea);
        setVisible(true);
    }
    private void showPanel(String name) { cardLayout.show(contentArea, name); }
    private JPanel buildLoginPanel() {
        JPanel root = new JPanel(new GridBagLayout()); root.setBackground(BG);
        JPanel card = darkCard(420, 500);
        JLabel logo = lbl("🏠 RealEstate Pro", 24, ACCENT, Font.BOLD);
        logo.setAlignmentX(CENTER_ALIGNMENT);
        JLabel sub = lbl("Find your perfect property", 13, MUTED, Font.PLAIN);
        sub.setAlignmentX(CENTER_ALIGNMENT);
        JTextField emailFld = field(); emailFld.setMaximumSize(new Dimension(9999,40));
        JPasswordField passFld = new JPasswordField(); styleField(passFld);
        passFld.setEchoChar('●'); passFld.setMaximumSize(new Dimension(9999,40));
        JLabel errLbl = lbl(" ", 12, RED, Font.PLAIN);
        errLbl.setAlignmentX(CENTER_ALIGNMENT);
        JButton loginBtn = btn("Login", ACCENT);
        loginBtn.addActionListener(e -> {
            String em = emailFld.getText().trim();
            String pw = new String(passFld.getPassword());
            try {
                Customer c = findCustomer(em, pw);
                loggedInCustomer = c;
                rebuildBrowse(); refreshWishlist();
                refreshPurchases(); refreshProfile();
                refreshAgents(); updateTopBar();
                showPanel("DASHBOARD");
            } catch (UserNotFoundException ex) {
                errLbl.setText(ex.getMessage());
            }
        });
        JButton regBtn = flatBtn("Don't have an account? Register");
        regBtn.addActionListener(e -> showPanel("REGISTER"));
        JLabel hint = lbl("Test login: ahmed@gmail.com / pass001", 11, MUTED, Font.ITALIC);
        hint.setAlignmentX(CENTER_ALIGNMENT);
        card.add(logo); vs(card,6); card.add(sub); vs(card,30);
        card.add(fl("Email")); vs(card,4); card.add(emailFld); vs(card,14);
        card.add(fl("Password")); vs(card,4); card.add(passFld); vs(card,8);
        card.add(errLbl); vs(card,14); card.add(loginBtn);
        vs(card,10); card.add(regBtn); vs(card,16); card.add(hint);
        root.add(card); return root;
    }
    private JPanel buildRegisterPanel() {
        JPanel root = new JPanel(new GridBagLayout()); root.setBackground(BG);
        JPanel card = darkCard(430, 570);
        JLabel title = lbl("Create Account", 22, TEXT, Font.BOLD);
        title.setAlignmentX(CENTER_ALIGNMENT);
        JTextField nameFld = field(); nameFld.setMaximumSize(new Dimension(9999,40));
        JTextField emailFld = field(); emailFld.setMaximumSize(new Dimension(9999,40));
        JPasswordField pFld = new JPasswordField(); styleField(pFld);
        pFld.setEchoChar('●'); pFld.setMaximumSize(new Dimension(9999,40));
        JTextField phoneFld = field(); phoneFld.setMaximumSize(new Dimension(9999,40));
        JTextField budgetFld = field(); budgetFld.setMaximumSize(new Dimension(9999,40));
        JLabel errLbl = lbl(" ", 12, RED, Font.PLAIN);
        errLbl.setAlignmentX(CENTER_ALIGNMENT);
        JButton regBtn = btn("Register", GREEN);
        regBtn.addActionListener(e -> {
            try {
                String nm = nameFld.getText().trim();
                String em = emailFld.getText().trim();
                String pw = new String(pFld.getPassword());
                String ph = phoneFld.getText().trim();
                if (nm.isEmpty() || em.isEmpty() || pw.isEmpty())
                throw new InvalidPropertyException("Name, email and password are required.");
                double bud;
                try {
                    bud = Double.parseDouble(budgetFld.getText().trim());
                    if (bud <= 0)
                    throw new InvalidPropertyException("Budget must be greater than zero.");
                } catch (NumberFormatException ex2) {
                    throw new InvalidPropertyException("Budget must be a valid number.");
                }
                for (Customer c : customers)
                if (c.getEmail().equalsIgnoreCase(em))
                throw new InvalidPropertyException("Email already registered.");
                Customer nc = new Customer( "C" + (customers.size() + 1001), nm, em, ph.isEmpty() ? "N/A" : ph, pw, bud);
                customers.add(nc);
                FileManager.saveAll(allProperties, customers, agents);
                loggedInCustomer = nc;
                rebuildBrowse(); refreshWishlist();
                refreshPurchases(); refreshProfile();
                refreshAgents(); updateTopBar();
                showPanel("DASHBOARD");
            } catch (InvalidPropertyException ex) {
                errLbl.setText(ex.getMessage());
            }
        });
        JButton backBtn = flatBtn("Already registered? Login");
        backBtn.addActionListener(e -> showPanel("LOGIN"));
        card.add(title); vs(card,22);
        card.add(fl("Full Name")); vs(card,4); card.add(nameFld);
        vs(card,12);
        card.add(fl("Email")); vs(card,4); card.add(emailFld);
        vs(card,12);
        card.add(fl("Password")); vs(card,4); card.add(pFld);
        vs(card,12);
        card.add(fl("Phone (optional)")); vs(card,4); card.add(phoneFld);
        vs(card,12);
        card.add(fl("Budget (USD)")); vs(card,4); card.add(budgetFld);
        vs(card,8);
        card.add(errLbl); vs(card,14); card.add(regBtn); vs(card,10);
        card.add(backBtn);
        root.add(card); return root;
    }
    private JPanel buildDashboard() {
        JPanel root = new JPanel(new BorderLayout()); root.setBackground(BG);
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(SURFACE); sidebar.setPreferredSize(new Dimension(200,0));
        sidebar.setBorder(new EmptyBorder(20,0,20,0));
        JLabel brand = lbl(" 🏠 RealEstate", 15, ACCENT, Font.BOLD);
        brand.setAlignmentX(LEFT_ALIGNMENT);
        sidebar.add(brand); sidebar.add(Box.createVerticalStrut(28));
        String[] names = {"Browse","Search","Wishlist","Purchases","Agents","EMI Calc","Profile"};
        String[] icons = {"🏘","🔍","❤","🛒","👔","💰","👤"};
        for (int i = 0; i < names.length; i++) {
            final String key = names[i].toUpperCase().replace(" ","");
            JButton nb = navBtn(icons[i] + " " + names[i]);
            nb.addActionListener(e -> dashCards.show(dashContent, key));
            sidebar.add(nb); sidebar.add(Box.createVerticalStrut(3));
        }
        sidebar.add(Box.createVerticalGlue());
        JButton logoutBtn = navBtn("⬅ Logout"); logoutBtn.setForeground(RED);
        logoutBtn.addActionListener(e -> { loggedInCustomer = null;
            showPanel("LOGIN"); });
        sidebar.add(logoutBtn);
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(SURFACE); topBar.setBorder(new EmptyBorder(13,20,13,20));
        topBar.setPreferredSize(new Dimension(0,56));
        welcomeLbl = lbl("Welcome!", 15, TEXT, Font.BOLD);
        budgetLbl = lbl("Budget: --", 13, GREEN, Font.PLAIN);
        JPanel tl = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
        tl.setOpaque(false);
        tl.add(welcomeLbl); tl.add(Box.createHorizontalStrut(20));
        tl.add(budgetLbl);
        topBar.add(tl, BorderLayout.WEST);
        dashCards = new CardLayout();
        dashContent = new JPanel(dashCards); dashContent.setBackground(BG);
        browseGrid = new JPanel(new GridLayout(0,3,14,14));
        browseGrid.setBackground(BG);
        JPanel browseRoot = panel18(); browseRoot.add(lbl("Browse Properties",20,TEXT,Font.BOLD), BorderLayout.NORTH);
        browseRoot.add(scroll(browseGrid), BorderLayout.CENTER);
        wishGrid = new JPanel(new GridLayout(0,3,14,14));
        wishGrid.setBackground(BG);
        JPanel wishRoot = panel18(); wishRoot.add(lbl("My Wishlist ❤",20,TEXT,Font.BOLD), BorderLayout.NORTH);
        wishRoot.add(scroll(wishGrid), BorderLayout.CENTER);
        purBox = new JPanel(); purBox.setLayout(new BoxLayout(purBox,BoxLayout.Y_AXIS)); purBox.setBackground(BG);
        JPanel purRoot = panel18(); purRoot.add(lbl("My Purchases 🛒",20,TEXT,Font.BOLD), BorderLayout.NORTH);
        purRoot.add(scroll(purBox), BorderLayout.CENTER);
        agentsBox = new JPanel(); agentsBox.setLayout(new BoxLayout(agentsBox,BoxLayout.Y_AXIS)); agentsBox.setBackground(BG);
        JPanel agentsRoot = panel18(); agentsRoot.add(lbl("Our Agents 👔",20,TEXT,Font.BOLD), BorderLayout.NORTH);
        agentsRoot.add(scroll(agentsBox), BorderLayout.CENTER);
        profileBox = new JPanel(); profileBox.setLayout(new BoxLayout(profileBox,BoxLayout.Y_AXIS));
        profileBox.setBackground(CARD); profileBox.setBorder(new EmptyBorder(30,40,30,40));
        profileBox.setPreferredSize(new Dimension(440,400));
        JPanel profRoot = new JPanel(new GridBagLayout());
        profRoot.setBackground(BG); profRoot.add(profileBox);
        dashContent.add(browseRoot, "BROWSE");
        dashContent.add(buildSearchPanel(), "SEARCH");
        dashContent.add(wishRoot, "WISHLIST");
        dashContent.add(purRoot, "PURCHASES");
        dashContent.add(agentsRoot, "AGENTS");
        dashContent.add(buildEMIPanel(), "EMICALC");
        dashContent.add(profRoot, "PROFILE");
        root.add(sidebar, BorderLayout.WEST);
        root.add(topBar, BorderLayout.NORTH);
        root.add(dashContent, BorderLayout.CENTER);
        return root;
    }
    private JPanel panel18() {
        JPanel p = new JPanel(new BorderLayout(0,12));
        p.setBackground(BG); p.setBorder(new EmptyBorder(18,18,18,18)); return
        p;
    }
    private void updateTopBar() {
        if (loggedInCustomer == null) return;
        welcomeLbl.setText("Welcome, " + loggedInCustomer.getName() + "!");
        budgetLbl.setText(String.format("Budget: $%.0f", loggedInCustomer.getBudget()));
    }
    private JPanel buildSearchPanel() {
        JPanel root = panel18();
        JPanel fr = new JPanel(new FlowLayout(FlowLayout.LEFT,10,6));
        fr.setBackground(BG);
        JTextField locFld = smallField("Location...");
        JTextField maxFld = smallField("Max price...");
        JComboBox<String> typeCb = new JComboBox<>( new String[]{"All","House","Apartment","Villa","Commercial Space"});
        typeCb.setBackground(SURFACE); typeCb.setForeground(TEXT);
        typeCb.setFont(new Font("Segoe UI",Font.PLAIN,13));
        JButton go = btn("Search", ACCENT); go.setPreferredSize(new Dimension(90,34));
        fr.add(lbl("Location:",13,MUTED,Font.PLAIN)); fr.add(locFld);
        fr.add(lbl("Max $:",13,MUTED,Font.PLAIN)); fr.add(maxFld);
        fr.add(lbl("Type:",13,MUTED,Font.PLAIN)); fr.add(typeCb);
        fr.add(go);
        JPanel rg = new JPanel(new GridLayout(0,3,14,14)); rg.setBackground(BG);
        go.addActionListener(e -> {
            rg.removeAll();
            String loc = locFld.getText().trim().toLowerCase();
            String maxS = maxFld.getText().trim();
            String type = (String) typeCb.getSelectedItem();
            for (Property p : allProperties) {
                if (!loc.isEmpty() &&
                !p.getLocation().toLowerCase().contains(loc)) continue;
                if (!maxS.isEmpty()) {
                    try { if (p.getPrice() > Double.parseDouble(maxS)) continue;
                    }
                    catch (NumberFormatException ignored) {}
                }
                if (!"All".equals(type) && !p.getType().equals(type)) continue;
                rg.add(propertyCard(p));
            }
            if (rg.getComponentCount() == 0)
            rg.add(lbl("No results found.", 14, MUTED, Font.PLAIN));
            rg.revalidate(); rg.repaint();
        });
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(BG);
        top.add(lbl("Search Properties",20,TEXT,Font.BOLD), BorderLayout.NORTH);
        top.add(fr, BorderLayout.CENTER);
        root.add(top, BorderLayout.NORTH);
        root.add(scroll(rg), BorderLayout.CENTER);
        return root;
    }
    private JPanel buildEMIPanel() {
        JPanel root = new JPanel(new GridBagLayout()); root.setBackground(BG);
        JPanel card = darkCard(460,460);
        JLabel title = lbl("EMI Calculator 💰",20,TEXT,Font.BOLD);
        title.setAlignmentX(CENTER_ALIGNMENT);
        JTextField lf = field(); lf.setMaximumSize(new Dimension(9999,40));
        JTextField rf = field(); rf.setMaximumSize(new Dimension(9999,40));
        JTextField mf = field(); mf.setMaximumSize(new Dimension(9999,40));
        JTextArea ra = new JTextArea(7,32); ra.setEditable(false);
        ra.setBackground(SURFACE); ra.setForeground(TEXT);
        ra.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13)); ra.setBorder(new EmptyBorder(10,12,10,12));
        JButton cb = btn("Calculate EMI", GOLD); cb.setForeground(Color.BLACK);
        cb.addActionListener(e -> {
            try {
                double loan = Double.parseDouble(lf.getText().trim());
                double rate = Double.parseDouble(rf.getText().trim());
                int mon = Integer.parseInt(mf.getText().trim());
                if (loan <= 0 || rate <= 0 || mon <= 0)
                throw new InvalidPropertyException("All values must be greater than zero.");
                double r = rate / 12 / 100;
                double emi = r == 0 ? loan / mon
                : (loan * r * Math.pow(1+r,mon)) /
                (Math.pow(1+r,mon)-1);
                double tot = emi * mon;
                ra.setText(String.format( "Loan Amount : $%.2f%n" + "Interest Rate : %.2f%% / year%n" + "Tenure : %d months (%.1f years)%n" + "Monthly EMI : $%.2f%n" + "Total Payment : $%.2f%n" + "Total Interest : $%.2f", loan, rate, mon, mon/12.0, emi, tot, tot-loan));
            } catch (InvalidPropertyException ex) {
                ra.setText("Error: " + ex.getMessage());
            } catch (NumberFormatException ex) {
                ra.setText("Please enter valid numbers in all fields.");
            }
        });
        card.add(title); vs(card,20);
        card.add(fl("Loan Amount ($)")); vs(card,4); card.add(lf);
        vs(card,12);
        card.add(fl("Interest Rate (%)")); vs(card,4); card.add(rf);
        vs(card,12);
        card.add(fl("Tenure (months)")); vs(card,4); card.add(mf);
        vs(card,16);
        card.add(cb); vs(card,14); card.add(ra);
        root.add(card); return root;
    }
    private void rebuildBrowse() {
        browseGrid.removeAll();
        for (Property p : allProperties) browseGrid.add(propertyCard(p));
        browseGrid.revalidate(); browseGrid.repaint();
    }
    private void refreshWishlist() {
        wishGrid.removeAll();
        if (loggedInCustomer == null) { wishGrid.revalidate();
            wishGrid.repaint(); return; }
        for (String name : loggedInCustomer.getWishlist()) {
            Property p = findByName(name);
            if (p != null) wishGrid.add(propertyCard(p));
        }
        if (loggedInCustomer.getWishlist().isEmpty())
        wishGrid.add(lbl("Your wishlist is empty.", 14, MUTED, Font.PLAIN));
        wishGrid.revalidate(); wishGrid.repaint();
    }
    private void refreshPurchases() {
        purBox.removeAll();
        if (loggedInCustomer == null) { purBox.revalidate(); purBox.repaint();
            return; }
        for (String name : loggedInCustomer.getPurchases()) {
            JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT));
            row.setBackground(CARD); row.setBorder(new EmptyBorder(10,14,10,14));
            row.setMaximumSize(new Dimension(9999,48));
            row.add(lbl(" " + name, 14, GREEN, Font.PLAIN));
            purBox.add(row); purBox.add(Box.createVerticalStrut(5));
        }
        if (loggedInCustomer.getPurchases().isEmpty())
        purBox.add(lbl("No purchases yet.", 14, MUTED, Font.PLAIN));
        purBox.revalidate(); purBox.repaint();
    }
    private void refreshAgents() {
        agentsBox.removeAll();
        vs(agentsBox, 10);
        for (Agent a : agents) {
            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(CARD);
            card.setBorder(BorderFactory.createCompoundBorder( new LineBorder(BORDER,1,true), new EmptyBorder(16,20,16,20)));
            card.setMaximumSize(new Dimension(9999, 160));
            JLabel nameLbl = lbl("👔 " + a.getName(), 15, TEXT, Font.BOLD);
            JLabel idLbl = lbl("ID: " + a.getUserID(), 12, MUTED, Font.PLAIN);
            JLabel emailLbl= lbl("Email: " + a.getEmail(), 12, MUTED, Font.PLAIN);
            JLabel phoneLbl= lbl("Phone: " + a.getPhone(), 12, MUTED, Font.PLAIN);
            JLabel licLbl = lbl("License: " + a.getAgentLicense(), 12, ACCENT, Font.PLAIN);
            JLabel commLbl = lbl("Commission Rate: " + a.getCommissionRate() + "%", 12, GOLD, Font.PLAIN);
            JLabel earnLbl = lbl(String.format("Total Earnings: $%.2f", a.getTotalEarnings()), 12, GREEN, Font.PLAIN);
            card.add(nameLbl); vs(card,6);
            card.add(idLbl); vs(card,3);
            card.add(emailLbl);vs(card,3);
            card.add(phoneLbl);vs(card,3);
            card.add(licLbl); vs(card,3);
            card.add(commLbl); vs(card,3);
            card.add(earnLbl);
            agentsBox.add(card);
            agentsBox.add(Box.createVerticalStrut(10));
        }
        agentsBox.revalidate(); agentsBox.repaint();
    }
    private void refreshProfile() {
        profileBox.removeAll();
        if (loggedInCustomer == null) return;
        Customer c = loggedInCustomer;
        JLabel t = lbl("👤 My Profile",20,TEXT,Font.BOLD);
        t.setAlignmentX(CENTER_ALIGNMENT);
        profileBox.add(t); vs(profileBox,24);
        String[][] rows = {
            {"Name", c.getName()}, {"Email", c.getEmail()}, {"Phone", c.getPhone()}, {"Role", c.getRole()}, {"Budget", String.format("$%.2f",c.getBudget())}, {"Wishlist", c.getWishlist().size() + " properties"}, {"Purchases",c.getPurchases().size() + " properties"}
        };
        for (String[] row : rows) {
            JPanel line = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
            line.setBackground(CARD); line.setMaximumSize(new Dimension(9999,30));
            line.add(lbl(row[0]+": ",13,MUTED,Font.PLAIN));
            line.add(lbl(row[1], 13,TEXT, Font.PLAIN));
            profileBox.add(line); vs(profileBox,8);
        }
        profileBox.revalidate(); profileBox.repaint();
    }
    private JPanel propertyCard(Property p) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(CARD);
        card.setBorder(BorderFactory.createCompoundBorder( new LineBorder(BORDER,1,true), new EmptyBorder(14,16,14,16)));
        JPanel brow = new JPanel(new FlowLayout(FlowLayout.LEFT,0,0));
        brow.setOpaque(false);
        JLabel badge = lbl(" "+p.getType()+" ",11,Color.BLACK,Font.BOLD);
        badge.setOpaque(true); badge.setBackground(typeColor(p.getType()));
        badge.setBorder(new EmptyBorder(2,6,2,6)); brow.add(badge);
        if (!"Available".equals(p.getStatus())) {
            JLabel sb = lbl(" SOLD ",11,Color.WHITE,Font.BOLD);
            sb.setOpaque(true); sb.setBackground(RED); sb.setBorder(new EmptyBorder(2,6,2,6));
            brow.add(Box.createHorizontalStrut(5)); brow.add(sb);
        }
        String det = "";
        if (p instanceof House) det = ((House)p).getDetails();
        else if (p instanceof Apartment) det = ((Apartment)p).getDetails();
        else if (p instanceof Villa) det = ((Villa)p).getDetails();
        else if (p instanceof Commercial_Space) det = ((Commercial_Space)p).getDetails();
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.LEFT,5,0));
        btnRow.setOpaque(false);
        JButton detBtn = smBtn("Details", ACCENT);
        JButton wishBtn = smBtn("❤ Save", new Color(200,70,70));
        JButton buyBtn = smBtn("Buy", GREEN);
        detBtn.addActionListener(e -> showDetails(p));
        wishBtn.addActionListener(e -> {
            if (loggedInCustomer == null) {
                JOptionPane.showMessageDialog(this,"Please login first.");
                return;
            }
            loggedInCustomer.addToWishlist(p.getName());
            FileManager.saveAll(allProperties, customers, agents);
            refreshWishlist();
            JOptionPane.showMessageDialog(this, p.getName() + " saved to wishlist!");
        });
        buyBtn.addActionListener(e -> {
            try {
                doBuy(p);
            } catch (PropertyNotAvailableException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Not Available", JOptionPane.WARNING_MESSAGE);
            }
        });
        btnRow.add(detBtn); btnRow.add(wishBtn);
        if ("Available".equals(p.getStatus())) btnRow.add(buyBtn);
        card.add(brow);
        vs(card,7);
        card.add(lbl(p.getName(),15,TEXT,Font.BOLD));
        vs(card,3);
        card.add(lbl("📍 "+p.getLocation(),12,MUTED,Font.PLAIN));
        vs(card,7);
        card.add(lbl(String.format("$%.0f",p.getPrice()),17,ACCENT,Font.BOLD));
        vs(card,3);
        card.add(lbl(String.format("Tax: $%.0f",p.calculateTax()),11,MUTED,Font.PLAIN)); vs(card,3);
        card.add(lbl(det,11,MUTED,Font.PLAIN));
        vs(card,10);
        card.add(btnRow);
        return card;
    }
    private void showDetails(Property p) {
        p.display();
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-16s%s%n","Name:", p.getName()));
        sb.append(String.format("%-16s%s%n","Type:", p.getType()));
        sb.append(String.format("%-16s%s%n","Location:", p.getLocation()));
        sb.append(String.format("%-16s$%.0f%n","Price:", p.getPrice()));
        sb.append(String.format("%-16s%s%n","Area:", p.getArea()));
        sb.append(String.format("%-16s$%.2f%n","Tax:", p.calculateTax()));
        sb.append(String.format("%-16s%s%n","Status:", p.getStatus()));
        sb.append(String.format("%-16s%s%n","Agent:", p.getAgentName()));
        sb.append("\n--- Specific Details ---\n");
        if (p instanceof House)
        sb.append(((House)p).getDetails());
        else if (p instanceof Apartment)
        sb.append(((Apartment)p).getDetails());
        else if (p instanceof Villa)
        sb.append(((Villa)p).getDetails());
        else if (p instanceof Commercial_Space)
        sb.append(((Commercial_Space)p).getDetails());
        JTextArea ta = new JTextArea(sb.toString());
        ta.setEditable(false); ta.setBackground(CARD); ta.setForeground(TEXT);
        ta.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13)); ta.setBorder(new EmptyBorder(10,10,10,10));
        JOptionPane.showMessageDialog(this, new JScrollPane(ta), "Property — "+p.getName(), JOptionPane.PLAIN_MESSAGE);
    }
    private void doBuy(Property p) throws PropertyNotAvailableException {
        if (loggedInCustomer == null) {
            JOptionPane.showMessageDialog(this,"Please login first."); return;
        }
        if (!"Available".equals(p.getStatus()))
        throw new PropertyNotAvailableException(p.getName());
        double fullPrice = p.getPrice();
        double tax = p.calculateTax();
        double agentFee = defaultAgent.getCommissionRate() / 100 * fullPrice;
        double total = fullPrice + tax + agentFee;
        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(CARD); form.setBorder(new EmptyBorder(16,20,16,20));
        form.add(lbl("Property: " + p.getName(), 14, TEXT, Font.BOLD));
        vs(form,4);
        form.add(lbl("Type: " + p.getType(), 13, MUTED, Font.PLAIN));
        vs(form,4);
        form.add(lbl(String.format("Price: $%.0f", fullPrice), 13, MUTED, Font.PLAIN)); vs(form,4);
        form.add(lbl(String.format("Tax: $%.0f", tax), 13, MUTED, Font.PLAIN)); vs(form,4);
        form.add(lbl(String.format("Agent Fee: $%.0f", agentFee), 13, MUTED, Font.PLAIN)); vs(form,6);
        JLabel totalLbl = lbl(String.format("Total (full): $%.0f", total), 14, ACCENT, Font.BOLD);
        form.add(totalLbl); vs(form,20);
        form.add(lbl("── Payment Method ──",13,MUTED,Font.PLAIN)); vs(form,10);
        JRadioButton fullBtn = new JRadioButton("Full Payment");
        JRadioButton emiBtn = new JRadioButton("EMI / Loan");
        fullBtn.setOpaque(false); fullBtn.setForeground(TEXT);
        fullBtn.setSelected(true);
        emiBtn.setOpaque(false); emiBtn.setForeground(TEXT);
        ButtonGroup bg = new ButtonGroup(); bg.add(fullBtn); bg.add(emiBtn);
        form.add(fullBtn); vs(form,6); form.add(emiBtn); vs(form,20);
        form.add(lbl("── EMI Details ──",13,MUTED,Font.PLAIN)); vs(form,10);
        JTextField dpFld = smallField("e.g. 50000");
        JTextField rateFld = smallField("e.g. 8.5");
        JTextField monFld = smallField("e.g. 120");
        addFormRow(form,"Down Payment ($):", dpFld); vs(form,10);
        addFormRow(form,"Interest Rate (%):",rateFld); vs(form,10);
        addFormRow(form,"Tenure (months):", monFld); vs(form,10);
        dpFld.setEnabled(false); rateFld.setEnabled(false);
        monFld.setEnabled(false);
        fullBtn.addActionListener(e -> {
            dpFld.setEnabled(false); rateFld.setEnabled(false);
            monFld.setEnabled(false);
            totalLbl.setText(String.format("Total (full): $%.0f", total));
        });
        emiBtn.addActionListener(e -> {
            dpFld.setEnabled(true); rateFld.setEnabled(true);
            monFld.setEnabled(true);
            totalLbl.setText("Enter EMI details below");
        });
        JScrollPane formScroll = new JScrollPane(form);
        formScroll.setPreferredSize(new Dimension(500, 420));
        formScroll.setBackground(CARD);
        formScroll.getViewport().setBackground(CARD);
        formScroll.setBorder(new LineBorder(BORDER,1));
        formScroll.getVerticalScrollBar().setUnitIncrement(12);
        int res = JOptionPane.showConfirmDialog(this, formScroll, "Purchase — " + p.getName(), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return;
        try {
            String invoice;
            if (emiBtn.isSelected()) {
                double dp, rate; int mon;
                try {
                    dp = Double.parseDouble(dpFld.getText().trim());
                    rate = Double.parseDouble(rateFld.getText().trim());
                    mon = Integer.parseInt(monFld.getText().trim());
                } catch (NumberFormatException ex2) {
                    throw new InvalidPropertyException("Enter valid numbers for all EMI fields.");
                }
                if (dp < 0) throw new InvalidPropertyException("Down payment cannot be negative.");
                if (rate <= 0) throw new InvalidPropertyException("Interest rate must be positive.");
                if (mon <= 0) throw new InvalidPropertyException("Tenure must be positive.");
                if (dp >= fullPrice) throw new InvalidPropertyException("Down payment cannot exceed property price.");
                double loan = fullPrice - dp;
                double r = rate / 12 / 100;
                double emi = r == 0 ? loan / mon
                : (loan * r * Math.pow(1+r,mon)) /
                (Math.pow(1+r,mon)-1);
                double need = dp + tax + agentFee;
                if (!loggedInCustomer.canAfford(need))
                throw new InsufficientBudgetException(loggedInCustomer.getBudget(), need);
                loggedInCustomer.deductBudget(need);
                p.setStatus("Sold");
                loggedInCustomer.addPurchase(p.getName());
                defaultAgent.addListing(p.getName());
                invoice = buildInvoice(p, fullPrice, tax, agentFee, total, true, emi, mon);
            } else {
                if (!loggedInCustomer.canAfford(total))
                throw new InsufficientBudgetException(loggedInCustomer.getBudget(), total);
                loggedInCustomer.deductBudget(total);
                p.setStatus("Sold");
                loggedInCustomer.addPurchase(p.getName());
                defaultAgent.addListing(p.getName());
                invoice = buildInvoice(p, fullPrice, tax, agentFee, total, false, 0, 0);
            }
            FileManager.saveAll(allProperties, customers, agents);
            updateTopBar(); rebuildBrowse();
            refreshWishlist(); refreshPurchases();
            refreshProfile(); refreshAgents();
            JTextArea ta = new JTextArea(invoice);
            ta.setEditable(false); ta.setBackground(CARD);
            ta.setForeground(TEXT);
            ta.setFont(new Font(Font.MONOSPACED,Font.PLAIN,13));
            ta.setBorder(new EmptyBorder(10,10,10,10));
            JOptionPane.showMessageDialog(this, new JScrollPane(ta), "Purchase Invoice", JOptionPane.PLAIN_MESSAGE);
        } catch (InsufficientBudgetException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Insufficient Budget", JOptionPane.ERROR_MESSAGE);
        } catch (InvalidPropertyException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void addFormRow(JPanel parent, String labelText, JTextField field) {
        JPanel row = new JPanel(new BorderLayout(10,0));
        row.setBackground(CARD); row.setMaximumSize(new Dimension(9999,36));
        row.add(lbl(labelText, 12, MUTED, Font.PLAIN), BorderLayout.WEST);
        row.add(field, BorderLayout.CENTER);
        parent.add(row);
    }
    private String buildInvoice(Property p, double price, double tax, double fee, double total, boolean emi, double monthlyEMI, int months) {
        StringBuilder sb = new StringBuilder();
        sb.append("======== PURCHASE INVOICE ========\n");
        sb.append(String.format("Property : %s%n", p.getName()));
        sb.append(String.format("Type : %s%n", p.getType()));
        sb.append(String.format("Location : %s%n", p.getLocation()));
        sb.append(String.format("Customer : %s%n", loggedInCustomer.getName()));
        sb.append(String.format("Agent : %s%n", defaultAgent.getName()));
        sb.append("----------------------------------\n");
        sb.append(String.format("Price : $%.2f%n", price));
        sb.append(String.format("Tax : $%.2f%n", tax));
        sb.append(String.format("Agent Fee: $%.2f%n", fee));
        sb.append(String.format("Total : $%.2f%n", total));
        if (emi)
        sb.append(String.format("EMI : $%.2f/month x %d months%n", monthlyEMI, months));
        else
        sb.append("Payment : Full Payment\n");
        sb.append("Status : SOLD\n");
        sb.append(String.format("Rem Budget: $%.2f%n", loggedInCustomer.getBudget()));
        sb.append("==================================\n");
        return sb.toString();
    }
    private Customer findCustomer(String email, String pass) throws
    UserNotFoundException {
        for (Customer c : customers)
        if (c.getEmail().equalsIgnoreCase(email) &&
        c.getPassword().equals(pass)) return c;
        throw new UserNotFoundException(email);
    }
    private Property findByName(String name) {
        for (Property p : allProperties)
        if (p.getName().equalsIgnoreCase(name)) return p;
        return null;
    }
    private Color typeColor(String t) {
        switch (t) {
            case "House": return new Color(88, 196, 88);
            case "Apartment": return new Color(88, 166, 255);
            case "Villa": return new Color(255,196, 61);
            case "Commercial Space": return new Color(200,130,255);
            default: return MUTED;
        }
    }
    private JLabel lbl(String t, int sz, Color c, int style) {
        JLabel l = new JLabel(t); l.setFont(new Font("Segoe UI",style,sz));
        l.setForeground(c); return l; }
    private JLabel fl(String t) {
        JLabel l = lbl(t,12,MUTED,Font.PLAIN); l.setAlignmentX(LEFT_ALIGNMENT);
        return l; }
    private JTextField field() {
        JTextField f = new JTextField(); styleField(f); return f; }
    private void styleField(JTextField f) {
        f.setAlignmentX(LEFT_ALIGNMENT); f.setBackground(SURFACE);
        f.setForeground(TEXT); f.setCaretColor(TEXT);
        f.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(6,12,6,12)));
        f.setFont(new Font("Segoe UI",Font.PLAIN,14)); }
    private JTextField smallField(String hint) {
        JTextField f = new JTextField(14); f.setPreferredSize(new Dimension(160,32));
        f.setBackground(SURFACE); f.setForeground(TEXT); f.setCaretColor(TEXT);
        f.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(4,8,4,8)));
        f.setFont(new Font("Segoe UI",Font.PLAIN,13)); return f; }
    private JButton btn(String t, Color bg) {
        JButton b = new JButton(t); b.setAlignmentX(LEFT_ALIGNMENT);
        b.setMaximumSize(new Dimension(9999,42));
        b.setBackground(bg); b.setForeground(Color.WHITE); b.setFont(new Font("Segoe UI",Font.BOLD,14));
        b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b; }
    private JButton flatBtn(String t) {
        JButton b = new JButton(t); b.setAlignmentX(CENTER_ALIGNMENT);
        b.setOpaque(false); b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setForeground(MUTED); b.setFont(new Font("Segoe UI",Font.PLAIN,12));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b; }
    private JButton navBtn(String t) {
        JButton b = new JButton(t); b.setMaximumSize(new Dimension(9999,40));
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.setBackground(SURFACE); b.setForeground(TEXT); b.setFont(new Font("Segoe UI",Font.PLAIN,13));
        b.setBorderPainted(false); b.setFocusPainted(false);
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setBorder(new EmptyBorder(8,20,8,20));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); return b; }
    private JButton smBtn(String t, Color bg) {
        JButton b = new JButton(t); b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI",Font.PLAIN,12));
        b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(76,28)); return b; }
    private JPanel darkCard(int w, int h) {
        JPanel c = new JPanel(); c.setLayout(new BoxLayout(c,BoxLayout.Y_AXIS));
        c.setBackground(CARD);
        c.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDER,1,true),new EmptyBorder(36,46,36,46)));
        c.setPreferredSize(new Dimension(w,h)); return c; }
    private JScrollPane scroll(JPanel p) {
        JScrollPane s = new JScrollPane(p); s.setBackground(BG);
        s.getViewport().setBackground(BG);
        s.setBorder(null); s.getVerticalScrollBar().setUnitIncrement(16); return
        s; }
    private void vs(JPanel p, int h) { p.add(Box.createVerticalStrut(h)); }
    public static void main(String[] args) {
        System.out.println("=== RealEstate Pro — Starting ===\n");
        FileManager.init();
        ArrayList<Property> properties = new ArrayList<>();
        ArrayList<Customer> customers = new ArrayList<>();
        ArrayList<Agent> agents = new ArrayList<>();
        try {
            properties = FileManager.loadProperties();
            customers = FileManager.loadCustomers();
            agents = FileManager.loadAgents();
        } catch (FileCorruptedException e) {
            System.out.println("WARNING: " + e.getMessage());
            System.out.println("Starting with empty data.\n");
            properties = new ArrayList<>();
            customers = new ArrayList<>();
            agents = new ArrayList<>();
        }
        if (agents.isEmpty()) {
            System.out.println("No agents found — seeding 5 agents...");
            agents.add(new Agent("A001","Rahim Uddin", "rahim@realty.com", "01711-001","agent001","LIC-BD-001",2.5));
            agents.add(new Agent("A002","Karim Hossain", "karim@realty.com", "01711-002","agent002","LIC-BD-002",2.0));
            agents.add(new Agent("A003","Farida Begum", "farida@realty.com", "01711-003","agent003","LIC-BD-003",2.8));
            agents.add(new Agent("A004","Nasir Ahmed", "nasir@realty.com", "01711-004","agent004","LIC-BD-004",2.2));
            agents.add(new Agent("A005","Sadia Islam", "sadia@realty.com", "01711-005","agent005","LIC-BD-005",3.0));
            FileManager.saveAgents(agents);
        }
        if (customers.isEmpty()) {
            System.out.println("No customers found — seeding 5 customers...");
            customers.add(new Customer("C001","Ahmed Hossain", "ahmed@gmail.com", "01811-001","pass001",800000));
            customers.add(new Customer("C002","Sara Begum", "sara@gmail.com", "01811-002","pass002",350000));
            customers.add(new Customer("C003","Rafiq Islam", "rafiq@gmail.com", "01811-003","pass003",600000));
            customers.add(new Customer("C004","Nusrat Jahan", "nusrat@gmail.com","01811-004","pass004",450000));
            customers.add(new Customer("C005","Sabbir Rahman", "sabbir@gmail.com","01811-005","pass005",920000));
            FileManager.saveCustomers(customers);
        }
        if (properties.isEmpty()) {
            System.out.println("No properties found — seeding 80 properties...");
            properties.add(new House("H001","Green Haven", "Austin, TX", 320000,"1800 sqft",2,true, true));
            properties.add(new House("H002","Maple Cottage", "Denver, CO", 195000,"1100 sqft",1,false,true));
            properties.add(new House("H003","Brick Manor", "Boston, MA", 450000,"2400 sqft",3,true, true));
            properties.add(new House("H004","Cedar Ridge", "Portland, OR", 275000,"1550 sqft",2,true, false));
            properties.add(new House("H005","Sunset Bungalow","Nashville, TN", 215000,"1200 sqft",1,false,true));
            properties.add(new House("H006","Rosewood Home", "Atlanta, GA", 360000,"2000 sqft",2,true, true));
            properties.add(new House("H007","Willow Creek", "Seattle, WA", 420000,"2200 sqft",2,true, true));
            properties.add(new House("H008","Oak Valley", "Phoenix, AZ", 290000,"1700 sqft",2,false,true));
            properties.add(new House("H009","Pine Nest", "Minneapolis,MN",240000,"1350 sqft",1,true, false));
            properties.add(new House("H010","Birch Hill", "Charlotte, NC", 310000,"1900 sqft",2,true, true));
            properties.add(new House("H011","Elmwood", "San Antonio,TX",280000,"1650 sqft",2,false,false));
            properties.add(new House("H012","Aspen Grove", "Salt Lake, UT", 330000,"1800 sqft",2,true, true));
            properties.add(new House("H013","Magnolia Way", "Raleigh, NC", 265000,"1500 sqft",1,false,true));
            properties.add(new House("H014","Spruce Lane", "Kansas City,MO",195000,"1100 sqft",1,true, false));
            properties.add(new House("H015","Chestnut Place", "Indianapolis,IN",230000,"1300 sqft",2,true,true));
            properties.add(new House("H016","Foxglove Court", "Columbus, OH", 250000,"1400 sqft",2,false,true));
            properties.add(new House("H017","Ironwood", "Louisville, KY",210000,"1250 sqft",1,true, false));
            properties.add(new House("H018","Hazel Path", "Memphis, TN", 188000,"1050 sqft",1,false,true));
            properties.add(new House("H019","Laurel Bend", "Richmond, VA", 340000,"1950 sqft",2,true, true));
            properties.add(new House("H020","Thornwood", "Omaha, NE", 222000,"1280 sqft",2,false,false));
            properties.add(new Apartment("AP01","Skyline Suite", "New York, NY", 280000,"950 sqft", 12,"Skyline Tower", true, true));
            properties.add(new Apartment("AP02","Urban Nest", "Chicago, IL", 175000,"600 sqft", 4,"Central Bldg", true, false));
            properties.add(new Apartment("AP03","Harbor View", "San Francisco,CA",390000,"800 sqft", 18,"Harbor Point", true, true));
            properties.add(new Apartment("AP04","Metro Flat", "Los Angeles,CA", 310000,"750 sqft", 9,"Metro Hub", true, true));
            properties.add(new Apartment("AP05","Riverside Apt", "Miami, FL", 260000,"700 sqft", 6,"Riverside Plaza",false,true));
            properties.add(new Apartment("AP06","Lakeview", "Minneapolis,MN", 190000,"620 sqft", 3,"Lakeview Bldg", true, false));
            properties.add(new Apartment("AP07","The Pinnacle", "Dallas, TX", 220000,"680 sqft", 15,"Pinnacle Tower", true, true));
            properties.add(new Apartment("AP08","Civic Center", "Washington, DC", 340000,"820 sqft", 10,"Civic Arms", true, true));
            properties.add(new Apartment("AP09","Park Residency", "Philadelphia,PA", 230000,"710 sqft", 7,"Park Block", false,false));
            properties.add(new Apartment("AP10","Horizon Flats", "Houston, TX", 200000,"640 sqft", 5,"Horizon Bldg", true, true));
            properties.add(new Apartment("AP11","Midtown Studio", "New York, NY", 185000,"480 sqft", 22,"Midtown Rise", true, true));
            properties.add(new Apartment("AP12","Gateway Apt", "Atlanta, GA", 210000,"660 sqft", 8,"Gateway Suites",true, false));
            properties.add(new Apartment("AP13","Copper Mill", "Denver, CO", 195000,"630 sqft", 4,"Copper Bldg", false,true));
            properties.add(new Apartment("AP14","Sunrise Apt", "Phoenix, AZ", 180000,"590 sqft", 3,"Sunrise Court", true, true));
            properties.add(new Apartment("AP15","Bay Breeze", "San Diego, CA", 295000,"730 sqft", 11,"Bay Point", true, true));
            properties.add(new Apartment("AP16","Summit View", "Seattle, WA", 285000,"720 sqft", 14,"Summit Towers", true, false));
            properties.add(new Apartment("AP17","Crossroads", "Austin, TX", 215000,"670 sqft", 6,"Crossroads Bldg",false,true));
            properties.add(new Apartment("AP18","Emerald Place", "Portland, OR", 225000,"690 sqft", 5,"Emerald Block", true, true));
            properties.add(new Apartment("AP19","Cardinal Apt", "Louisville, KY", 165000,"560 sqft", 3,"Cardinal Arms", false,false));
            properties.add(new Apartment("AP20","Highrise 360", "Charlotte, NC", 235000,"700 sqft", 19,"360 Tower", true, true));
            properties.add(new Villa("V001","Ocean Pearl", "Miami, FL", 850000,"4200 sqft",true, 2.5,true));
            properties.add(new Villa("V002","Sunset Ridge", "Malibu, CA", 1200000,"5800 sqft",true, 3.2,true));
            properties.add(new Villa("V003","Palm Oasis", "Palm Springs, CA", 980000,"4500 sqft",true, 1.8,false));
            properties.add(new Villa("V004","Lakeshore Villa", "Lake Tahoe, NV", 760000,"3800 sqft",true, 2.0,true));
            properties.add(new Villa("V005","Mountain Retreat","Aspen, CO", 1350000,"6200 sqft",false,4.1,true));
            properties.add(new Villa("V006","Coastal Dream", "Santa Barbara,CA", 920000,"4100 sqft",true, 2.3,false));
            properties.add(new Villa("V007","Desert Rose", "Scottsdale, AZ", 690000,"3500 sqft",true, 1.5,true));
            properties.add(new Villa("V008","Emerald Cove", "Key West, FL", 870000,"4000 sqft",true, 2.8,true));
            properties.add(new Villa("V009","Northwood", "Lake Geneva, WI", 610000,"3200 sqft",false,1.7,false));
            properties.add(new Villa("V010","Seaview Estate", "Outer Banks, NC", 730000,"3700 sqft",true, 2.1,true));
            properties.add(new Villa("V011","Vineyard Hills", "Napa, CA", 1100000,"5400 sqft",true, 3.5,true));
            properties.add(new Villa("V012","Canyon View", "Sedona, AZ", 780000,"3900 sqft",true, 2.2,false));
            properties.add(new Villa("V013","Whispering Pines","Vail, CO", 950000,"4600 sqft",false,3.0,true));
            properties.add(new Villa("V014","Blue Horizon", "Hilton Head, SC", 660000,"3300 sqft",true, 1.9,true));
            properties.add(new Villa("V015","Royal Palms", "Boca Raton, FL", 890000,"4300 sqft",true, 2.6,true));
            properties.add(new Villa("V016","Sunrise Estate", "Naples, FL", 820000,"4100 sqft",true, 2.4,false));
            properties.add(new Villa("V017","Silver Creek", "Jackson Hole, WY",1050000,"5100 sqft",false,3.8,true));
            properties.add(new Villa("V018","Coral Bay", "Sarasota, FL", 740000,"3750 sqft",true, 2.0,true));
            properties.add(new Villa("V019","Highland Manor", "Asheville, NC", 680000,"3400 sqft",true, 1.6,false));
            properties.add(new Villa("V020","Ivory Gate", "Savannah, GA", 710000,"3600 sqft",true, 2.3,true));
            properties.add(new Commercial_Space("CS01","Downtown Hub", "Chicago, IL", 420000,"2500 sqft","Office", 20,true));
            properties.add(new Commercial_Space("CS02","Market Square", "Dallas, TX", 310000,"1800 sqft","Retail", 12,false));
            properties.add(new Commercial_Space("CS03","Tech Park", "San Jose, CA", 560000,"3200 sqft","Office", 35,true));
            properties.add(new Commercial_Space("CS04","Warehouse One", "Houston, TX", 280000,"5000 sqft","Warehouse",40,false));
            properties.add(new Commercial_Space("CS05","Plaza Center", "Los Angeles,CA", 490000,"2800 sqft","Retail", 18,true));
            properties.add(new Commercial_Space("CS06","Flex Space", "Seattle, WA", 370000,"2100 sqft","Mixed", 15,true));
            properties.add(new Commercial_Space("CS07","Commerce Court", "New York, NY", 720000,"3500 sqft","Office", 25,true));
            properties.add(new Commercial_Space("CS08","Industrial Zone", "Detroit, MI", 220000,"6000 sqft","Warehouse",50,false));
            properties.add(new Commercial_Space("CS09","Retail Row", "Atlanta, GA", 330000,"1900 sqft","Retail", 10,false));
            properties.add(new Commercial_Space("CS10","Business Bay", "Miami, FL", 410000,"2400 sqft","Office", 22,true));
            properties.add(new Commercial_Space("CS11","Innovation Hub", "Austin, TX", 480000,"2900 sqft","Office", 28,true));
            properties.add(new Commercial_Space("CS12","Strip Mall", "Phoenix, AZ", 260000,"2000 sqft","Retail", 16,false));
            properties.add(new Commercial_Space("CS13","Logistics Ctr", "Columbus, OH", 300000,"7000 sqft","Warehouse",60,false));
            properties.add(new Commercial_Space("CS14","Corporate Suite", "Boston, MA", 610000,"3300 sqft","Office", 30,true));
            properties.add(new Commercial_Space("CS15","Artisan Market", "Portland, OR", 290000,"1700 sqft","Retail", 8,false));
            properties.add(new Commercial_Space("CS16","Midway Flex", "Kansas City,MO", 240000,"2200 sqft","Mixed", 12,true));
            properties.add(new Commercial_Space("CS17","Harbor Trade", "Baltimore, MD", 350000,"2600 sqft","Warehouse",20,false));
            properties.add(new Commercial_Space("CS18","Skybridge Office","Denver, CO", 430000,"2700 sqft","Office", 24,true));
            properties.add(new Commercial_Space("CS19","Cornerstone", "Nashville, TN", 315000,"2100 sqft","Retail", 14,true));
            properties.add(new Commercial_Space("CS20","Northgate Ctr", "Minneapolis,MN", 385000,"2500 sqft","Office", 20,true));
            FileManager.saveProperties(properties);
        }
        System.out.println("\n=== Loaded Data Summary ===");
        System.out.println("Properties : " + properties.size());
        System.out.println("Customers : " + customers.size());
        System.out.println("Agents : " + agents.size());
        System.out.println("\n--- Customers ---");
        for (Customer c : customers)
        System.out.printf(" [%s] %-16s email: %-24s budget: $%.0f%n", c.getUserID(), c.getName(), c.getEmail(), c.getBudget());
        System.out.println("\n--- Agents ---");
        for (Agent a : agents)
        System.out.printf(" [%s] %-16s license: %-12s commission: %.1f%%%n", a.getUserID(), a.getName(), a.getAgentLicense(), a.getCommissionRate());
        System.out.println("\nAll data files in: data/");
        System.out.println(" - data/properties.txt");
        System.out.println(" - data/customers.txt");
        System.out.println(" - data/agents.txt");
        System.out.println("\nLaunching GUI...");
        final ArrayList<Property> fp = properties;
        final ArrayList<Customer> fc = customers;
        final ArrayList<Agent> fa = agents;
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new Main(fp, fc, fa);
        });
    }
}
