package users;
import java.util.ArrayList;
public class Customer extends User {
    private double budget;
    private ArrayList<String> wishlist;
    private ArrayList<String> purchases;
    public Customer() {
    }
    public Customer(String userID, String name, String email, String phone, String password, double budget) {
        super(userID, name, email, phone, password);
        this.budget = budget;
        this.wishlist = new ArrayList<>();
        this.purchases = new ArrayList<>();
    }
    public double getBudget() {
        return budget;
    }
    public void setBudget(double budget) {
        this.budget = budget;
    }
    public ArrayList<String> getWishlist() {
        return wishlist;
    }
    public void setWishlist(ArrayList<String> wishlist) {
        this.wishlist = wishlist;
    }
    public ArrayList<String> getPurchases() {
        return purchases;
    }
    public void setPurchases(ArrayList<String> purchases) {
        this.purchases = purchases;
    }
    public void addToWishlist(String propertyName) {
        if (!wishlist.contains(propertyName)) {
            wishlist.add(propertyName);
        }
    }
    public void removeFromWishlist(String propertyName) {
        wishlist.remove(propertyName);
    }
    public void addPurchase(String propertyName) {
        purchases.add(propertyName);
    }
    public boolean canAfford(double price) {
        return budget >= price;
    }
    public void deductBudget(double amount) {
        budget -= amount;
    }
    public void displayProfile() {
        System.out.println("=== Customer Profile ===");
        System.out.println(super.toString());
        System.out.println("Role : " + getRole());
        System.out.println("Budget : $" + budget);
        System.out.println("Wishlist : " + wishlist.size() + " properties");
        System.out.println("Purchases: " + purchases.size() + " properties");
    }
    @Override
    public String getRole() {
        return "Customer";
    }
    public String toFileString() {
        String w = String.join(",", wishlist);
        String p = String.join(",", purchases);
        return super.toString() + "|" + budget + "|" + (w.isEmpty() ? "NONE" : w) + "|" + (p.isEmpty() ? "NONE" : p);
    }
}
