package users;
import java.util.ArrayList;
public class Agent extends User{
    private String agentLicense;
    private double commissionRate;
    private ArrayList<String> listings;
    private double totalEarnings;
    public Agent() {
    }
    public Agent(String userID, String name, String email, String phone, String password, String agentLicense, double commissionRate) {
        super(userID, name, email, phone, password);
        this.agentLicense = agentLicense;
        this.commissionRate = commissionRate;
        this.listings = new ArrayList<>();
        this.totalEarnings = 0.0;
    }
    public String getAgentLicense() {
        return agentLicense;
    }
    public void setAgentLicense(String agentLicense) {
        this.agentLicense = agentLicense;
    }
    public double getCommissionRate() {
        return commissionRate;
    }
    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }
    public ArrayList<String> getListings() {
        return listings;
    }
    public void setListings(ArrayList<String> listings) {
        this.listings = listings;
    }
    public double getTotalEarnings() {
        return totalEarnings;
    }
    public void setTotalEarnings(double totalEarnings) {
        this.totalEarnings = totalEarnings;
    }
    public void addListing(String propertyName) {
        if (!listings.contains(propertyName)) listings.add(propertyName);
    }
    public void removeListing(String propertyName) {
        listings.remove(propertyName);
    }
    public double calculateCommission(double salePrice) {
        double commission = (commissionRate / 100) * salePrice;
        totalEarnings += commission;
        return commission;
    }
    @Override
    public void displayProfile() {
        System.out.println("=== Agent Profile ===");
        System.out.println(super.toString());
        System.out.println("Role : " + getRole());
        System.out.println("License : " + agentLicense);
        System.out.println("Commission Rate: " + commissionRate + "%");
        System.out.println("Total Listings : " + listings.size());
        System.out.println("Total Earnings : $" + totalEarnings);
    }
    @Override
    public String getRole() {
        return "Agent";
    }
    public String toFileString() {
        return super.toString() + "|" + agentLicense + "|" + commissionRate + "|" + totalEarnings;
    }
}
