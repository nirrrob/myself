package Storage;
import Exceptions.FileCorruptedException;
import Properties.Apartment;
import Properties.Commercial_Space;
import Properties.House;
import Properties.Property;
import Properties.Villa;
import users.Agent;
import users.Customer;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
/** Simple text-file persistence for the RealEstate Pro demo application. */
public final class FileManager {
    private static final Path DATA_DIR = Paths.get("data");
    private static final Path PROPERTIES_FILE = DATA_DIR.resolve("properties.txt");
    private static final Path CUSTOMERS_FILE = DATA_DIR.resolve("customers.txt");
    private static final Path AGENTS_FILE = DATA_DIR.resolve("agents.txt");
    private FileManager() { }
    public static void init() {
        try {
            Files.createDirectories(DATA_DIR);
            if (Files.notExists(PROPERTIES_FILE)) Files.createFile(PROPERTIES_FILE);
            if (Files.notExists(CUSTOMERS_FILE)) Files.createFile(CUSTOMERS_FILE);
            if (Files.notExists(AGENTS_FILE)) Files.createFile(AGENTS_FILE);
        } catch (IOException e) {
            throw new IllegalStateException("Could not initialize the data directory.", e);
        }
    }
    public static ArrayList<Property> loadProperties() throws FileCorruptedException {
        ArrayList<Property> result = new ArrayList<>();
        for (String line : readLines(PROPERTIES_FILE)) {
            if (line.trim().isEmpty()) continue;
            try {
                String[] f = line.split("\\|", -1);
                String type = f[0];
                String id = f[1], name = f[2], location = f[3];
                double price = Double.parseDouble(f[4]);
                String area = f[5];
                Property p;
                switch (type) {
                    case "House":
                    p = new House(id, name, location, price, area,
                    Integer.parseInt(f[7]), Boolean.parseBoolean(f[8]), Boolean.parseBoolean(f[9]));
                    break;
                    case "Apartment":
                    p = new Apartment(id, name, location, price, area,
                    Integer.parseInt(f[7]), f[8], Boolean.parseBoolean(f[9]), Boolean.parseBoolean(f[10]));
                    break;
                    case "Villa":
                    p = new Villa(id, name, location, price, area,
                    Boolean.parseBoolean(f[7]), Double.parseDouble(f[8]), Boolean.parseBoolean(f[9]));
                    break;
                    case "Commercial Space":
                    p = new Commercial_Space(id, name, location, price, area,
                    f[7], Integer.parseInt(f[8]), Boolean.parseBoolean(f[9]));
                    break;
                    default:
                    throw new IllegalArgumentException("Unknown property type: " + type);
                }
                if (f.length > 6) p.setStatus(f[6]);
                result.add(p);
            } catch (RuntimeException ex) {
                throw new FileCorruptedException(PROPERTIES_FILE.toString());
            }
        }
        return result;
    }
    public static ArrayList<Customer> loadCustomers() throws FileCorruptedException {
        ArrayList<Customer> result = new ArrayList<>();
        for (String line : readLines(CUSTOMERS_FILE)) {
            if (line.trim().isEmpty()) continue;
            try {
                String[] f = line.split("\\|", -1);
                if (!"CUSTOMER".equals(f[0])) throw new IllegalArgumentException("Invalid customer record");
                Customer c = new Customer(f[1], f[2], f[3], f[4], f[5], Double.parseDouble(f[6]));
                if (f.length > 7 && !f[7].isEmpty() && !"NONE".equals(f[7]))
                for (String item : f[7].split(",")) c.addToWishlist(item);
                if (f.length > 8 && !f[8].isEmpty() && !"NONE".equals(f[8]))
                for (String item : f[8].split(",")) c.addPurchase(item);
                result.add(c);
            } catch (RuntimeException ex) {
                throw new FileCorruptedException(CUSTOMERS_FILE.toString());
            }
        }
        return result;
    }
    public static ArrayList<Agent> loadAgents() throws FileCorruptedException {
        ArrayList<Agent> result = new ArrayList<>();
        for (String line : readLines(AGENTS_FILE)) {
            if (line.trim().isEmpty()) continue;
            try {
                String[] f = line.split("\\|", -1);
                if (!"AGENT".equals(f[0])) throw new IllegalArgumentException("Invalid agent record");
                Agent a = new Agent(f[1], f[2], f[3], f[4], f[5], f[6], Double.parseDouble(f[7]));
                a.setTotalEarnings(Double.parseDouble(f[8]));
                if (f.length > 9 && !f[9].isEmpty() && !"NONE".equals(f[9]))
                for (String listing : f[9].split(",")) a.addListing(listing);
                result.add(a);
            } catch (RuntimeException ex) {
                throw new FileCorruptedException(AGENTS_FILE.toString());
            }
        }
        return result;
    }
    public static void saveAll(List<Property> properties, List<Customer> customers, List<Agent> agents) {
        saveProperties(properties);
        saveCustomers(customers);
        saveAgents(agents);
    }
    public static void saveProperties(List<Property> properties) {
        ArrayList<String> lines = new ArrayList<>();
        for (Property p : properties) {
            if (p instanceof House) lines.add(((House) p).toFileString());
            else if (p instanceof Apartment) lines.add(((Apartment) p).toFileString());
            else if (p instanceof Villa) lines.add(((Villa) p).toFileString());
            else if (p instanceof Commercial_Space) lines.add(((Commercial_Space) p).toFileString());
        }
        writeLines(PROPERTIES_FILE, lines);
    }
    public static void saveCustomers(List<Customer> customers) {
        ArrayList<String> lines = new ArrayList<>();
        for (Customer c : customers) {
            String wishlist = c.getWishlist().isEmpty() ? "NONE" : String.join(",", c.getWishlist());
            String purchases = c.getPurchases().isEmpty() ? "NONE" : String.join(",", c.getPurchases());
            lines.add(String.join("|", "CUSTOMER", c.getUserID(), c.getName(), c.getEmail(),
            c.getPhone(), c.getPassword(), Double.toString(c.getBudget()), wishlist, purchases));
        }
        writeLines(CUSTOMERS_FILE, lines);
    }
    public static void saveAgents(List<Agent> agents) {
        ArrayList<String> lines = new ArrayList<>();
        for (Agent a : agents) {
            String listings = a.getListings().isEmpty() ? "NONE" : String.join(",", a.getListings());
            lines.add(String.join("|", "AGENT", a.getUserID(), a.getName(), a.getEmail(), a.getPhone(),
            a.getPassword(), a.getAgentLicense(), Double.toString(a.getCommissionRate()),
            Double.toString(a.getTotalEarnings()), listings));
        }
        writeLines(AGENTS_FILE, lines);
    }
    private static List<String> readLines(Path path) throws FileCorruptedException {
        try {
            return Files.readAllLines(path, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new FileCorruptedException(path.toString());
        }
    }
    private static void writeLines(Path path, List<String> lines) {
        try {
            Files.createDirectories(DATA_DIR);
            Files.write(path, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalStateException("Could not save " + path + ".", e);
        }
    }
}
