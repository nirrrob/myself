package Services;
public class EMICalculator {
    private double loanAmount;
    private double annualInterestRate;
    private int tenureMonths;
    public EMICalculator(double loanAmount, double annualInterestRate, int tenureMonths) {
        this.loanAmount = loanAmount;
        this.annualInterestRate = annualInterestRate;
        this.tenureMonths = tenureMonths;
    }
    public double calculateEMI() {
        double r = annualInterestRate / 12 / 100;
        if (r == 0) return loanAmount / tenureMonths;
        return (loanAmount * r * Math.pow(1+r, tenureMonths)) / (Math.pow(1+r, tenureMonths) - 1);
    }
    public double totalPayment() { return calculateEMI() * tenureMonths; }
    public double totalInterest() { return totalPayment() - loanAmount; }
}
