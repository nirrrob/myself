package Properties;
public class Villa extends Property{
    private boolean hasPool;
    private double landArea;
    private boolean hasGuestHouse;
    public Villa() {
    }
    public Villa(String propertyID, String name, String location, double price, String area, boolean hasPool, double landArea, boolean hasGuestHouse) {
        super(propertyID, name, location, price, area);
        this.hasPool = hasPool;
        this.landArea = landArea;
        this.hasGuestHouse = hasGuestHouse;
    }
    public boolean isHasPool() {
        return hasPool;
    }
    public void setHasPool(boolean hasPool) {
        this.hasPool = hasPool;
    }
    public double getLandArea() {
        return landArea;
    }
    public void setLandArea(double landArea) {
        this.landArea = landArea;
    }
    public boolean isHasGuestHouse() {
        return hasGuestHouse;
    }
    public void setHasGuestHouse(boolean hasGuestHouse) {
        this.hasGuestHouse = hasGuestHouse;
    }
    public String ynpool() {
        if (this.isHasPool()) {
            return "Yes";
        } else {
            return "No";
        }
    }
    public String ynguesthouse() {
        if (this.isHasGuestHouse()) {
            return "Yes";
        } else {
            return "No";
        }
    }
    public void display(){
        System.out.println("Proper name: "+this.getName()+" | Id: " + this.getPropertyID() + " | Area: " + this.getArea());
        System.out.println("Pool: " + this.ynpool() + " | Land: " + this.getLandArea() + " | Guest House: " + this.ynguesthouse());
        System.out.println("Location: " + this.getLocation());
        System.out.println("Price" + this.getPrice());
    }
    public double calculateTax(){
        return (this.getPrice()*2.5)/100;
    }
    public String getType(){
        return "Villa";
    }
    public String toFileString() {
        return super.toString() + "|" + hasPool + "|" + landArea + "|" + hasGuestHouse;
    }
    public String getDetails() {
        return "Pool: " + ynpool() + " | Land: " + landArea + " acres | Guest House: " + ynguesthouse();
    }
}
