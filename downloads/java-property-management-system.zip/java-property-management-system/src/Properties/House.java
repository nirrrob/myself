package Properties;
public class House extends Property{
    private int floors;
    private boolean hasGarage;
    private boolean hasGarden;
    public House() {
    }
    public House(String propertyID, String name, String location, double price, String area, int floors, boolean hasGarage, boolean hasGarden) {
        super(propertyID, name, location, price, area);
        this.floors = floors;
        this.hasGarage = hasGarage;
        this.hasGarden = hasGarden;
    }
    public int getFloors() {
        return floors;
    }
    public void setFloors(int floors) {
        this.floors = floors;
    }
    public boolean isHasGarage() {
        return hasGarage;
    }
    public void setHasGarage(boolean hasGarage) {
        this.hasGarage = hasGarage;
    }
    public boolean isHasGarden() {
        return hasGarden;
    }
    public void setHasGarden(boolean hasGarden) {
        this.hasGarden = hasGarden;
    }
    public String yngarage(){
        if (this.isHasGarage())
        return "Yes";
        else{
            return "No";
        }
    }
    public String yngarden(){
        if (this.isHasGarden())
        return "Yes";
        else{
            return "No";
        }
    }
    public void display(){
        System.out.println("Proper name: "+this.getName()+" | Id: " + this.getPropertyID() + " | Area: " + this.getArea());
        System.out.println("Floors: " + this.getFloors() + " | Garage:"+ this.yngarage() + " | Garden:" + this.yngarden());
        System.out.println("Location: " + this.getLocation());
        System.out.println("Price: " + this.getPrice());
    }
    public double calculateTax(){
        return (super.getPrice()*1.2)/100;
    }
    public String getType(){
        return "House";
    }
    public String toFileString() {
        return super.toString() + "|" + floors + "|" + hasGarage + "|" + hasGarden;
    }
    public String getDetails() {
        return "Floors: " + floors + " | Garage: " + yngarage() + " | Garden: " + yngarden();
    }
}
