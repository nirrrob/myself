package Properties;
public class Apartment extends Property {
    private int floorNumber;
    private String buildingName;
    private boolean hasLift;
    private boolean hasSecurity;
    public Apartment() {
    }
    public Apartment(String propertyID, String name, String location, double price, String area, int floorNumber, String buildingName, boolean hasLift, boolean hasSecurity) {
        super(propertyID, name, location, price, area);
        this.floorNumber = floorNumber;
        this.buildingName = buildingName;
        this.hasLift = hasLift;
        this.hasSecurity = hasSecurity;
    }
    public int getFloorNumber() {
        return floorNumber;
    }
    public void setFloorNumber(int floorNumber) {
        this.floorNumber = floorNumber;
    }
    public String getBuildingName() {
        return buildingName;
    }
    public void setBuildingName(String buildingName) {
        this.buildingName = buildingName;
    }
    public boolean isHasLift() {
        return hasLift;
    }
    public void setHasLift(boolean hasLift) {
        this.hasLift = hasLift;
    }
    public boolean isHasSecurity() {
        return hasSecurity;
    }
    public void setHasSecurity(boolean hasSecurity) {
        this.hasSecurity = hasSecurity;
    }
    public String ynlift() {
        if (this.isHasLift()) {
            return "Yes";
        } else {
            return "No";
        }
    }
    public String ynSecurity() {
        if (this.isHasSecurity()) {
            return "Yes";
        } else {
            return "No";
        }
    }
    public void display() {
        System.out.println("Proper name: " + this.getName() + " | Id: " + this.getPropertyID() + " | Area: " + this.getArea());
        System.out.println("Floors: " + this.floorNumber + " | Lift: " + this.ynlift() + " | Security: " + this.ynSecurity());
        System.out.println("Location: " + this.getLocation());
        System.out.println("Price: " + this.getPrice());
    }
    public double calculateTax() {
        return (super.getPrice() * 0.8) / 100;
    }
    public String getType() {
        return "Apartment";
    }
    public String toFileString() {
        return super.toString() + "|" + floorNumber + "|" + buildingName + "|" + hasLift + "|" + hasSecurity;
    }
    public String getDetails() {
        return "Floor: " + floorNumber + " | Building: " + buildingName + " | Lift: " + ynlift() + " | Security: " + ynSecurity();
    }
}
