package Properties;
public abstract class Property {
    private String PropertyID;
    private String name;
    private String location;
    private double price;
    private String area;
    private String Status;
    private String AgentName;
    public Property() {
    }
    public Property(String propertyID, String name, String location, double price, String area) {
        this.PropertyID = propertyID;
        this.name = name;
        this.location = location;
        this.price = price;
        this.area = area;
        this.Status = "Available";
        this.AgentName = "Unaccessed";
    }
    public String getStatus() {
        return Status;
    }
    public void setStatus(String status) {
        Status = status;
    }
    public String getAgentName() {
        return AgentName;
    }
    public void setAgentName(String agentName) {
        AgentName = agentName;
    }
    public String getPropertyID() {
        return PropertyID;
    }
    public void setPropertyID(String propertyID) {
        PropertyID = propertyID;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    public String getArea() {
        return area;
    }
    public void setArea(String area) {
        this.area = area;
    }
    public String toString() {
        return
        this.getType()+"|"+this.PropertyID+"|"+this.getName()+"|"+this.getLocation()+"| "+this.getPrice()+"|"+area+"|"+Status;
    }
    public abstract void display();
    public abstract double calculateTax();
    public abstract String getType();
}
