package Properties;
public class Commercial_Space extends Property{
    private String businessType;
    private int parkingSlots;
    private boolean hasConferenceRoom;
    public Commercial_Space() {
    }
    public Commercial_Space(String propertyID, String name, String location, double price, String area, String businessType, int parkingSlots, boolean hasConferenceRoom) {
        super(propertyID, name, location, price, area);
        this.businessType = businessType;
        this.parkingSlots = parkingSlots;
        this.hasConferenceRoom = hasConferenceRoom;
    }
    public String getBusinessType() {
        return businessType;
    }
    public void setBusinessType(String businessType) {
        this.businessType = businessType;
    }
    public int getParkingSlots() {
        return parkingSlots;
    }
    public void setParkingSlots(int parkingSlots) {
        this.parkingSlots = parkingSlots;
    }
    public boolean isHasConferenceRoom() {
        return hasConferenceRoom;
    }
    public void setHasConferenceRoom(boolean hasConferenceRoom) {
        this.hasConferenceRoom = hasConferenceRoom;
    }
    public String ynconferenceroom(){
        if (this.isHasConferenceRoom()){
            return "Yes";
        }
        else return "No";
    }
    public void display(){
        System.out.println("Proper name: "+this.getName()+" | Id: " + this.getPropertyID() + " | Area: " + this.getArea());
        System.out.println("Type: " + this.getBusinessType() + " | Parking: " + this.getParkingSlots()+ " | Conference Room: " + this.ynconferenceroom());
        System.out.println("Location: " + this.getLocation());
        System.out.println("Price" + this.getPrice());
    }
    public double calculateTax(){
        return (this.getPrice()*3.0)/100;
    }
    public String getType(){
        return "Commercial Space";
    }
    public String toFileString() {
        return super.toString() + "|" + businessType + "|" + parkingSlots + "|" + hasConferenceRoom;
    }
    public String getDetails() {
        return "Type: " + businessType + " | Parking: " + parkingSlots + " slots | Conference: " + ynconferenceroom();
    }
}
