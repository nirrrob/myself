package Exceptions;
public class InsufficientBudgetException extends Exception{
    public InsufficientBudgetException(double budget, double required) {
        super(String.format("Insufficient budget. Your budget: $%.2f | Required: $%.2f | Shortfall: $%.2f", budget, required, required - budget));
    }
}
