package Exceptions;
public class FileCorruptedException extends Exception{
    public FileCorruptedException(String filename) {
        super("Data file '" + filename + "' is corrupted or has invalid format. Starting with empty data.");
    }
}
