package Exceptions;
public class PropertyNotAvailableException extends Exception{
    public PropertyNotAvailableException(String propertyName) {
        super("Property '" + propertyName + "' is not available. It may be sold or booked.");
    }
}
