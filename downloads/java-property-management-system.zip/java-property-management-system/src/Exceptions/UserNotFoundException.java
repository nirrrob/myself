package Exceptions;
public class UserNotFoundException extends Exception{
    public UserNotFoundException(String email) {
        super("No user found with email: " + email + ". Please register first.");
    }
}
