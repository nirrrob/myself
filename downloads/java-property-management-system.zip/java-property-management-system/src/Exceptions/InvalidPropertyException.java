package Exceptions;
public class InvalidPropertyException extends Exception{
    public InvalidPropertyException(String message) {
        super("Invalid property: " + message);
    }
}
