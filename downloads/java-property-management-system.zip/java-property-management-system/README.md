# RealEstate Pro — Property Management System

A Java Swing desktop application for browsing and managing residential and commercial properties. The project demonstrates object-oriented programming, GUI development, custom exceptions, EMI calculations, and basic text-file persistence.

## Features

- Customer registration and login
- Browse and search properties by location, price, and property type
- Property categories: houses, apartments, villas, and commercial spaces
- Property details, tax estimates, wishlists, and purchase records
- Purchase flow with full-payment and EMI options
- Monthly EMI, total-payment, and interest calculations
- Agent information and commission calculations
- Custom exceptions for invalid input, unavailable properties, insufficient budget, missing users, and corrupted data files
- Local text-file storage for properties, customers, and agents
- Dark-themed graphical interface built with Java Swing

## Technologies

- Java
- Java Swing / AWT
- Object-oriented programming (inheritance, abstraction, polymorphism, encapsulation)
- File I/O and custom exception handling

## Project structure

```text
java-property-management-system/
├── src/
│   ├── Main.java
│   ├── Exceptions/
│   ├── Properties/
│   ├── Services/
│   ├── Storage/
│   └── users/
├── data/                 # Runtime data is created here
├── .gitignore
└── README.md
```

## Requirements

- JDK 8 or later
- A desktop environment that supports Java Swing

## Run the application

### IntelliJ IDEA / Eclipse / VS Code

Open the project folder, mark `src` as a source folder if your IDE requires it, then run `Main.java`.

### Windows PowerShell

From the project root:

```powershell
New-Item -ItemType Directory -Force out | Out-Null
$files = Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { $_.FullName }
javac -encoding UTF-8 -d out $files
java -cp out Main
```

### macOS / Linux

From the project root:

```bash
mkdir -p out
javac -encoding UTF-8 -d out $(find src -name "*.java")
java -cp out Main
```

On first launch, the application creates the `data/` directory and initializes sample properties, customers, and agents. Subsequent changes are saved to text files in that directory.

## Demo login

The source includes a sample customer account for demonstration:

- **Email:** `ahmed@gmail.com`
- **Password:** `pass001`

If you want a clean demo state, close the app and remove the generated files under `data/`; they will be recreated on the next launch.

## Notes

- This is an educational project, not a production real-estate or financial application.
- The demo stores passwords in plain text and uses local text files. Do not use real personal information or real passwords.
- EMI and tax calculations are simplified examples and should not be treated as financial or legal advice.
